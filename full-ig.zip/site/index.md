﻿<div xmlns="http://www.w3.org/1999/xhtml" xsi:schemaLocation="http://hl7.org/fhir ../../src-generated/schemas/fhir-single.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <a name="scope"> </a>
  <h3>Scope</h3>
	
	<p>With this FHIR Implementation Guide eHealth Platform publishes guidelines, specific profiles and underlying valuesets, codesystems etc. as a federal initiative.</p>
	  <!--  -->
<p>As such, they are the base Belgian federal profiles and projects can use them, refer to them and build on them in their use cases.</p>

  <!-- <blockquote class="stu-note">
  <a name="dstu"></a>
Contact <a href="mailto:message-structure@ehealth.fgov.be">message-structure@ehealth.fgov.be</a> for any questions concerning this IG.
The working groups of HL7 and the different interested parties are still defining the process, the requirements and the tooling. This is a placeholder or sandbox for content, and not any recommendation or preview, so there is no guarantee of completeness or correctness.
</blockquote> -->
<p>
When needed, eHealth Platform does these publications as downloadable technical profiles according to the FHIR specs as published in this Implementation Guide. 
As a general rule, the FHIR standard is used as close as possible to the basic HL7 published standard. 
As a consequence of this, when needed eHealth Platform will only focus on nuances and clarifications 
between the Belgian initiative and the published standard.</p>

  <p>There will be no Belgian federal publications replacing or describing the overall
base specifications of the HL7 FHIR standard – the pages by HL7 are considered to be sufficient.</p>


<p>Implementers are encouraged to study the descriptions of the various
FHIR resources published by HL7, the published Belgian “be-“ profiles here and to
signal <a href="mailto:message-structure@ehealth.fgov.be">message-structure@ehealth.fgov.be</a>
concerning any ambiguities or initiatives that go outside of that realm. </p>

<p>Implementers SHALL take note every instance of a resource SHALL always
explicitely mark when a Belgian or other profile has been used. Implementers SHALL
be aware resources using different technical profiles might follow different
rules.</p>


<p>The Belgian profiling effort consists of an iterative approach. This
first iteration (Q4 2019) contains a basic set of guidelines, profiled resources and their supporting coding systems and valuesets.
In this first set, the profiled resources are Patient, Practitioner, PractitionerRole, Organization, Observation, Provenance and AllergyIntolerance.</p>

<p>Other profiles will be created and/or validated and added to this Belgian
set on an ongoing use case driven basis. </p>
	


This specification contains: 
	<ul>
      <!-- <li>Logical Models (in a future iteration), which describe describing several data sets and elements used in Belgian systems</li> -->
<li>Generalities on this page</li> 
<li>Content specifics on the <a href="guidance.html">Guidance page</a></li>   
    <li><a name="32f6716a-f990-46ab-a440-0641cccb407c">​</a><a href="artifacts.html#3">Value Sets and Code Systems</a>, containing specific Belgian value sets</li>
    <li><a name="340a39cd-2388-49e9-aa20-12f339ecee0c">​</a><a href="artifacts.html#1">Core profiles</a>, which constitute the basis for Belgian FHIR profiling and can be reused in other profiles </li>
    <li><a name="ed95d80a-544d-4739-b15e-37f0bc9cb1c0">​</a><a href="artifacts.html#2">Functional profiles</a>, split by functional area for ease of access</li>
	<li><a name="108b3023-c4e9-4652-923e-8fbc448ba6e3">​</a><a href="artifacts.html#5">Examples</a>, note every effort has been made to ensure the examples are correct and useful, but they are not a normative part of the specification.</li>
	</ul>
	  <!-- <ul>
    <li><a href="http://fhir.ivlab.ilabt.imec.be/be-fhir/artifacts.html#communication">Care coordination and Communication</a>, </li>
    <li><a href="http://fhir.ivlab.ilabt.imec.be/be-fhir/artifacts.html#communication">Patient conditions</a></li>
	</ul>
    <li>Required <a href="http://fhir.ivlab.ilabt.imec.be/be-fhir/artifacts.html#logical-models">Capability Statements</a> for systems to implement</li>
	</ul> -->
	<p>
    The implementation guide is structured to allow implementers to pick and choose the capabilities they need and combine them as necessary.
	</p>
	<a name="toc"> </a>
	<h3>Navigation</h3>
	<p>
    This implementation guide follows the FHIR pattern of being published as a web-based specification.  This
    allows easy navigation between the Belgium-specific portion of the implementation guide and the resources,
    data types, value sets and other specification components leveraged from the FHIR core specification.  This
    approach also allows implementers to easily navigate to the information needed to perform a task.
  </p>
	<p>
    A <a href="toc.html">Table of Contents</a> page is provided that lists all of the pages defined as part of this implementation guide.  (Do be aware 
    that some pages have multiple tabs.)  A table of contents is also available for the full <a href="http://hl7.org/fhir/R4/toc.html">FHIR specification</a> 
    if you really want to read absolutely everything.  There's also an <a href="artifacts.html">Artifact index</a> that lists all formal FHIR artifacts 
    defined within this implementation guide. General guidelines can be found on the <a href="guidance.html">Guidance page</a> that lists all guidelines and attention points that are not explicitely linked to a specific profile. The <i>Support</i> menu provides links to the HL7 standards used by this implementation guide as well as
    providing a <a href="downloads.html">Downloads</a> link to retrieve a local copy of this implementation guide and/or particular subsets of it.
  </p>
	<p>
    Breadcrumb navigation is provided in the gray bar just below the menu at the top of each page, allowing
    easy navigation back to the main page.
  </p>

  



	<a name="ip"> </a>
	<h3>Intellectual Property Considerations</h3>
	<p>
    While this implementation guide and the underlying FHIR are licensed as public domain, this guide includes examples making use of terminologies such 
    as LOINC, SNOMED CT and others which have more restrictive licensing requirements. Implementers should make themselves familiar with licensing and 
    any other constraints of terminologies, questionnaires, and other components used as part of their implementation process. In some cases, 
    licensing requirements may limit the systems that data captured using certain questionnaires may be shared with.
  </p>

	<a name="disclaimer"> </a>
	<h3>Disclaimer</h3>
	<p>
    The specification herewith documented is the first published version of the Belgian profiling initiative. Every effort has been made to remain within the FHIR standard and to be enabling in nature above all else. It is expected there will be further clarifications and guidelines in the future. Should an implementation encounter ambiguities due to this guide, your feedback is most welcome on <a href="mailto:message-structure@ehealth.fgov.be">message-structure@ehealth.fgov.be</a>. 
  </p>
  
</div>