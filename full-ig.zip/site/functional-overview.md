This section provides a functional overview of the implementation requirements. This is typically targeted at non-technical users, who can evaluate the needs, constraints, criteria and solutions without needing to analyse the technical documentation.

