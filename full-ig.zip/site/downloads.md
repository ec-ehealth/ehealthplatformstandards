<div xmlns="http://www.w3.org/1999/xhtml" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://hl7.org/fhir ../../src-generated/schemas/fhir-single.xsd">
	<p>
    Download the <a href="full-ig.zip">entire implementation guide</a>
	</p>
	<table>
		<tbody>
			<tr>
				<th>Artifact Definitions</th>
				<td>
					<a href="definitions.xml.zip">XML</a>
				</td>
				<td>
					<a href="definitions.json.zip">JSON</a>
				</td>
				<td>
					<a href="definitions.ttl.zip">Turtle</a>
				</td>
			</tr>
			<tr>
				<th>Examples</th>
				<td>
					<a href="examples.xml.zip">XML</a>
				</td>
				<td>
					<a href="examples.json.zip">JSON</a>
				</td>
				<td>
					<a href="examples.ttl.zip">Turtle</a>
				</td>
			</tr>
		</tbody>
	</table>
</div>
